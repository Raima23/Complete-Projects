ReadME.txt

mvn clean
mvn compile
mvn package






This code consists of a zoo manaagement system. you can enter as admin or visitor.
assumption is that feedback is a multiple line input
schedule events consists of option to close or open an available attraction
animal is a one word input

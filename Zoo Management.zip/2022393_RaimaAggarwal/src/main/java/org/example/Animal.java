package org.example;
import java.util.*;

public interface Animal {
    String name();
    String animalType();
    String makesound();
    String history();
}

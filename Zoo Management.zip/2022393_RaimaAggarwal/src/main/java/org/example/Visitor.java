package org.example;
import java.util.*;

public class Visitor {
    private String visitorName,email,password,membership;
    private double phone,balance;
    private List<Integer> tickets;
    int age;
    public Visitor(String visitorName, int age, double phone,double balance, String email, String password,List<Integer> tickets,String membership) {
        this.visitorName = visitorName;
        this.email = email;
        this.password = password;
        this.phone = phone;
        this.balance = balance;
        this.age = age;
        this.tickets=tickets;
        this.membership=membership;
    }

    public String getVisitorName() {
        return visitorName;
    }
    public void setVisitorName(String visitorName) {
        this.visitorName = visitorName;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public double getPhone() {
        return phone;
    }
    public void setPhone(double phone) {
        this.phone = phone;
    }
    public double getBalance() {
        return balance;
    }
    public void setBalance(double balance) {
        this.balance = balance;
    }
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }

    public List<Integer> getTickets() {
        return tickets;
    }

    public void setTickets(List<Integer> tickets) {
        this.tickets = tickets;
    }

    public String getMembership() {
        return membership;
    }

    public void setMembership(String membership) {
        this.membership = membership;
    }

}

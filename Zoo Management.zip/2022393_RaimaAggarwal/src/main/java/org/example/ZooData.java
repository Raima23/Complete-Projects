package org.example;
import java.util.*;
public class ZooData {
    private List<Animal> animals=new ArrayList<>();
    private List <String> feedback=new ArrayList<>();
    private List<Visitor> visitors=new ArrayList<>();
    private List <Attraction> attraction=new ArrayList<>();
    private List <Discounts> discount=new ArrayList<>();
    //private SpecialDeals specialDeal;
    private List<SpecialDeals> specialDeals=new ArrayList<>();
    //private List<Admin>adminData= new ArrayList<>();


    public ZooData(List<Visitor> visitors, List<SpecialDeals> specialDeals,List<String> feedback,List <Discounts> discount,List <Attraction> attraction,List<Animal> animals) {
        this.visitors = visitors;
        this.specialDeals = specialDeals;
        this.feedback=feedback;
        this.discount=discount;
        this.attraction=attraction;
        this.animals=animals;
    }

    public List<Animal> getAnimals() {
        return animals;
    }

    public void setAnimals(List<Animal> animals) {
        this.animals = animals;
    }

    public void setFeedback(List<String> feedback) {
        this.feedback = feedback;
    }

    public void setVisitors(List<Visitor> visitors) {
        this.visitors = visitors;
    }

    public void setAttraction(List<Attraction> attraction) {
        this.attraction = attraction;
    }

    public void setDiscount(List<Discounts> discount) {
        this.discount = discount;
    }

    public void setSpecialDeals(List<SpecialDeals> specialDeals) {
        this.specialDeals = specialDeals;
    }

    public List<Visitor> getVisitors() {
        return visitors;
    }

    public List<SpecialDeals> getSpecialDeals() {
        return specialDeals;
    }

    public List<String> getFeedback() {
        return feedback;
    }

    public List<Attraction> getAttraction() {
        return attraction;
    }

    public List<Discounts> getDiscount() {
        return discount;
    }

    public void removeAttraction(int attractionID){

    }
}

package org.example;
import java.util.*;

public class Assi2 {
    public static void main(String[] args){
        double totRev=0;
        Scanner sc=new Scanner(System.in);
        int attractionID=3;
        //String username="admin";
        //String password="pass123";
        List<Integer> tickets=new ArrayList<>();
        List<Animal> animals1 = new ArrayList<>();
        List <String> feedback1=new ArrayList<>();
        List<Visitor> visitors1 =new ArrayList<>();
        List<SpecialDeals> specialDeals1=new ArrayList<>();
        List <Discounts> discount1=new ArrayList<>();
        List<Attraction> attraction1=new ArrayList<>();
        ZooData zooData = new ZooData(visitors1,specialDeals1,feedback1,discount1,attraction1,animals1);
        Visitor predefvisitor=new Visitor("Abc", 25, 123456, 200, "abc@mail", "123",tickets,"none");
        Discounts predefDiscounts=new Discounts("Minor", 10, "MINOR10");
        Discounts predefDiscounts1=new Discounts("Senior Citizen", 20, "SENIOR20");
        SpecialDeals predefSpecialDeals=new SpecialDeals(2, 15);
        SpecialDeals predefSpecialDeals1=new SpecialDeals(3, 30);
        Attraction predefAttraction=new Attraction("Jungle Safari", "ZOOtopia offers an adventure ride that allows you to explore unexplored trails. Buy your ticket now!", 20, 1, 0, 1);
        Attraction predefAttraction2=new Attraction("Botanical garden", "This offers a captivating blend of wildlife and meticulously curated plant collections, creating a harmonious haven for both flora and fauna enthusiasts.", 30, 2,0, 1);
        Attraction predefAttraction3=new Attraction("Dinosaur Show", "An immersive prehistoric journey featuring lifelike dinosaur exhibits at the zoo.", 25, 3, 0, 1);
        Animal predefanimal=new Mammal("Elephant", "Trumpet", "Elephants are the largest terrestrial animals that are found in the dense forests of Asia and Africa. Elephants are wild animals that are always found in herds.");
        Animal predefAnimal2=new Mammal("Cow", "Moo", "The cow is an animal that can be domesticated. Cows are ubiquitous all over the world.");
        Animal predefAnimal3=new Amphibian("Fish", "Squeal", "There are more than 20000 species of fish including groups of Jawless fish, bony fish and sharks with varying size, shape and colours.");
        Animal predefAnimal4=new Amphibian("Toads", "trill", "In scientific taxonomy, toads include the true toads (Bufonidae) and various other terrestrial or warty-skinned frogs.");
        Animal predefAnimal5=new Reptile("Snake", "hiss", "Most species of snake are nonvenomous and those that have venom use it primarily to kill and subdue prey rather than for self-defense.");
        Animal predefAnimal6=new Reptile("Alligator", "growl", "These cold-blooded reptiles can grow from six to 11 feet long and inhabit wetland areas. American alligators can be found throughout Louisiana and Florida, where they were once nearly extinct. ");
        visitors1.add(predefvisitor);
        attraction1.add(predefAttraction);
        attraction1.add(predefAttraction2);
        attraction1.add(predefAttraction3);
        specialDeals1.add(predefSpecialDeals);
        specialDeals1.add(predefSpecialDeals1);
        discount1.add(predefDiscounts);
        discount1.add(predefDiscounts1);
        animals1.add(predefanimal);
        animals1.add(predefAnimal3);
        animals1.add(predefAnimal2);
        animals1.add(predefAnimal4);
        animals1.add(predefAnimal5);
        animals1.add(predefAnimal6);
        //System.out.println("\n\tWelcome to the Zoo Management System!");
        int mainChoice=0;
        while (mainChoice==0){
            System.out.println("Welcome to ZOOtopia!\n");
            System.out.println("1. Enter as admin\n2. Enter as a Visitor\n3. View Special Deals\n");
            int enterAs;
            enterAs =sc.nextInt();
            if (enterAs==1) {
                System.out.println("Enter Admin username: ");
                String enteredusername=sc.next();
                System.out.println("Enter Admin password: ");
                String enteredpassword=sc.next();
                //System.out.println(enteredusername+"   "+enteredpassword);
                if (enteredusername.equals("admin") && enteredpassword.equals("admin123")){
                    int adminMenu=0;
                    System.out.println("\nLogged in as Admin.\n");
                    while (adminMenu!=8){
                        System.out.println("Admin Menu:\n" + //
                                "1. Manage Attractions\n" + //
                                "2. Manage Animals\n" + //
                                "3. Schedule Events\n" + //
                                "4. Set Discounts\n" + //
                                "5. Set Special Deal\n" + //
                                "6. View Visitor Stats\n" + //
                                "7. View Feedback\n" + //
                                "8. Exit\n");
                        System.out.println("Enter your choice: ");
                        adminMenu=sc.nextInt();
                        switch (adminMenu){
                            case 8:
                                break;

                            case 1:
                                int attractionMenu=0;
                                while (attractionMenu!=5){
                                    System.out.println("\nManage Attractions:\n" + //
                                            "1. Add Attraction\n" + //
                                            "2. View Attractions\n" + //
                                            "3. Modify Attraction\n" + //
                                            "4. Remove Attraction\n" + //
                                            "5. Exit\n" + //
                                            "");
                                    System.out.println("Enter your choice: ");
                                    attractionMenu=sc.nextInt();
                                    switch(attractionMenu){
                                        case 5:
                                            break;
                                        case 1:
                                            System.out.println("Enter attraction name: ");
                                            String addAttractionName=sc.next();
                                            System.out.println("Enter attraction description: ");
                                            String addAttractionDescription=sc.nextLine();
                                            attractionID++;
                                            Attraction newAttraction=new Attraction(addAttractionName,addAttractionDescription,0,attractionID,0,1);
                                            attraction1.add(newAttraction);
                                            System.out.println("\nAttraction added successfully.\n");
                                            break;
                                        case 2:
                                            for (Attraction newAttractions:attraction1){
                                                System.out.println("Attraction ID: "+newAttractions.getAttractionID()+"\n"+newAttractions.getName()+"\n"+newAttractions.getDescription());
                                                System.out.println("\n");
                                            }
                                            break;
                                        case 3:
                                            System.out.println("Enter AttractionID: ");
                                            int modifyAttractionId=sc.nextInt();
                                            for (Attraction modifyAttraction:attraction1){
                                                if (modifyAttraction.getAttractionID()==modifyAttractionId) {
                                                    System.out.println("Current Name: "+modifyAttraction.getName());
                                                    System.out.println("Enter New Name: ");
                                                    String modifyNewName = sc.next();
                                                    System.out.println("Enter attraction description: ");
                                                    String modifyAttractionDescription=sc.nextLine();

                                                    modifyAttraction.setName(modifyNewName);
                                                    //modifyAttraction.setTicketPrice(modifyAttractionPrice);
                                                    modifyAttraction.setDescription(modifyAttractionDescription);
                                                }
                                            }
                                            System.out.println("\nAttraction Modified.\n");
                                            break;
                                        case 4:
                                            System.out.println("Enter AttractionID: ");
                                            int removeAttractionId=sc.nextInt();
                                            for(Attraction removeAttraction:attraction1){
                                                if(removeAttraction.getAttractionID()==removeAttractionId){
                                                    attraction1.remove(removeAttraction);
                                                }
                                            }
                                            System.out.println("\nAttraction Removed Successfully.\n");
                                            break;
                                        default:
                                            System.out.println("\nInvalid choice.\n");
                                    }}
                                break;
                            case 2:
                                System.out.println("1. Add animal\n"+
                                        "2. Modify Animal Details\n"+
                                        "3. Remove Animal\n");
                                System.out.println("Enter your choice: ");
                                switch (sc.nextInt()) {
                                    case 1:
                                        System.out.println("Enter name of the animal to be added: ");
                                        String addAnimalName=sc.next();
                                        System.out.println("Enter animal type: ");
                                        String addAnimalType=sc.next().toLowerCase();

                                        System.out.println("Enter sound of the animal: ");
                                        String addSound=sc.next();
                                        System.out.println("Enter animal history: ");
                                        String addHistory=" ";
                                        addHistory=sc.nextLine();

                                        switch(addAnimalType){
                                            case "mammal":
                                                Animal addAnimals=new Mammal(addAnimalName,addSound,addHistory);
                                                animals1.add(addAnimals);
                                                break;
                                            case "amphibian":
                                                Animal addAmphibians=new Amphibian(addAnimalName,addSound,addHistory);
                                                animals1.add(addAmphibians);
                                                break;
                                            case "reptile":
                                                Animal addReptiles=new Reptile(addAnimalName,addSound,addHistory);
                                                animals1.add(addReptiles);
                                                break;
                                            default:
                                                System.out.println("Invalid input.");
                                                break;
                                        }
                                        System.out.println("\nAnimal added successfully.\n");
                                        break;
                                    //Animal newAnimal=new Mammal()
                                    case 2:
                                        System.out.println("Enter name of the animal to be modified: ");
                                        String modAnimalName=sc.next();
                                        System.out.println("Enter animal type: ");
                                        String modAnimalType=sc.next();
                                        modAnimalType=modAnimalType.toLowerCase();
                                        System.out.println("Enter new sound of the animal: ");
                                        String modSound=sc.next();
                                        System.out.println("Enter new animal history: ");
                                        String modHistory="";
                                        modHistory=sc.nextLine();
                                        for(Animal animal:animals1){
                                            if(animal.name().equalsIgnoreCase(modAnimalName)){
                                                switch(modAnimalType){
                                                    case "mammal":
                                                        ((Mammal)animal).setSound(modSound);
                                                        ((Mammal)animal).setHistory(modHistory);
                                                        break;
                                                    case "amphibian":
                                                        ((Amphibian)animal).setSound(modSound);
                                                        ((Amphibian)animal).setHistory(modHistory);
                                                        break;
                                                    case "reptile":
                                                        ((Reptile)animal).setSound(modSound);
                                                        ((Reptile)animal).setHistory(modHistory);
                                                        break;
                                                    default:
                                                        System.out.println("Invalid input.");
                                                }
                                            }
                                        }
                                        break;
                                    case 3:
                                        System.out.println("Enter name of the animal to be deleted: ");
                                        String delAnimalName=sc.next();
                                        boolean check=false;
                                        for(Animal animal:animals1){
                                            if(animal.name().equalsIgnoreCase(delAnimalName)){
                                                animals1.remove(animal);
                                                check=true;
                                            }
                                        }
                                        if(check==false){
                                            System.out.println("Animal not found.");
                                        }
                                        break;
                                    default:
                                        System.out.println("Invalid choice.");

                                }
                                break;
                            case 3:
                                System.out.println("Enter Attraction ID: ");
                                int eventId=sc.nextInt();
                                for(Attraction event:attraction1){
                                    if(event.getAttractionID()==eventId){
                                        System.out.println("Event Name: "+event.getName());
                                        System.out.println("Status of Attraction: \n0-Closed\n1-Open\n");
                                        System.out.println("Enter current status: ");
                                        int eventStatus=sc.nextInt();
                                        System.out.println("Enter Ticket price: ");
                                        int eventPrice=sc.nextInt();
                                        event.setStatus(eventStatus);
                                        event.setTicketPrice(eventPrice);
                                    }}
                                break;
                            case 4:
                                int discountMenu=0;
                                while (discountMenu!=4){
                                    System.out.println("Set Discounts:\r\n" + //
                                            "1. Add Discount\r\n" + //
                                            "2. Modify Discount\r\n" + //
                                            "3. Remove Discount\r\n" + //
                                            "4. Exit\r\n" + //
                                            "");
                                    System.out.println("Enter your choice: ");
                                    discountMenu = sc.nextInt();
                                    switch(discountMenu){
                                        case 4:
                                            break;
                                        case 1:
                                            System.out.println("Enter Discount Category: ");
                                            String discategory = sc.next();
                                            System.out.println("Enter Discount percentage: ");
                                            double dispercentage = sc.nextDouble();
                                            System.out.println("Enter Discount code: ");
                                            String discode = sc.next();
                                            Discounts newDis=new Discounts(discategory,dispercentage,discode);
                                            discount1.add(newDis);
                                            break;
                                        case 2:
                                            System.out.println("Enter Discount code: ");
                                            String modCode = sc.next();
                                            boolean check=false;
                                            for(Discounts discountcode: discount1){
                                                if (discountcode.getCode().equalsIgnoreCase(modCode)){
                                                    check=true;
                                                    System.out.println("Enter new Discount percent: ");
                                                    double newPercentage = sc.nextDouble();
                                                    discountcode.setPercent(newPercentage);
                                                    System.out.println("Discount modified successfully.");
                                                    //break;
                                                }
                                            }
                                            if(check==false){
                                                System.out.println("No such discount found.\n");
                                            }
                                            break;
                                        case 3:
                                            System.out.println("Enter Discount code to be removed: ");
                                            String remCode = sc.next();
                                            boolean checkRemoved=false;
                                            for(Discounts discountcode: discount1){
                                                if (discountcode.getCode().equalsIgnoreCase(remCode)){
                                                    checkRemoved=true;
                                                    discount1.remove(discountcode);
                                                    //break;
                                                }}
                                            if (checkRemoved==false){
                                                System.out.println("No such discount found.\n");
                                            }
                                            break;
                                        default:
                                            System.out.println("Invalid Choice\n");
                                    }

                                }
                                break;
                            case 5:
                                System.out.println("1. Set new special deal\n2. Remove Special deal");
                                int spDealMenu = sc.nextInt();
                                switch(spDealMenu){
                                    case 1:
                                        System.out.println("Enter no of tickets: ");
                                        int numOfTickets=sc.nextInt();
                                        System.out.println("Enter Discount percentage: ");
                                        int dealPercentage=sc.nextInt();
                                        SpecialDeals newDeal=new SpecialDeals(numOfTickets,dealPercentage);
                                        specialDeals1.add(newDeal);
                                        System.out.println("\nNew deal added\n");
                                        break;
                                    case 2:
                                        System.out.println("Enter no of tickets: ");
                                        int noticket = sc.nextInt();
                                        boolean check=false;
                                        for(SpecialDeals deal:specialDeals1){
                                            if (deal.getNoTickets()==noticket){
                                                check=true;
                                                SpecialDeals dealrem=deal;
                                                //specialDeals1.remove(noticket);
                                                //break;1
                                                specialDeals1.remove(dealrem);
                                            }}
                                        if (check==false){
                                            System.out.println("No such deal found.\n");
                                        }

                                        break;
                                    default:
                                        System.out.println("Invalid choice.");
                                        break;
                                }

                                break;
                            case 6:
                                String popAttraction="";
                                int mostpop=0;
                                System.out.println("\nTotal Visitors: "+visitors1.size());
                                System.out.println("\nTotal Revenue: "+totRev);
                                for(Attraction pop:attraction1){
                                    if(pop.getNoofTickets()>mostpop){
                                        mostpop=pop.getNoofTickets();
                                        popAttraction=pop.getName();
                                    }
                                }
                                System.out.println("Most popular attraction: "+popAttraction);
                                break;
                            case 7:
                                List<String> feedback = zooData.getFeedback();
                                //specialDeals=getSpecialDeals();
                                for (String Feedback : feedback) {
                                    System.out.println(Feedback);
                                }
                                break;


                        }

                    }
                    System.out.println("Logged out.");
                }
            }

            else if(enterAs==2){
                boolean found=false;
                System.out.println("1.Register\n2.Login\n");
                System.out.print("Enter your choice: ");
                int newUser=sc.nextInt();
                if(newUser==1){
                    System.out.println("Enter Visitor Name: ");
                    String name = sc.next();
                    System.out.println("Enter Visitor Age: ");
                    int age = sc.nextInt();
                    sc.nextLine();  // Consume the newline character
                    System.out.println("Enter Visitor Phone Number: ");
                    double phoneNumber = sc.nextDouble();
                    System.out.println("Enter Visitor Balance: ");
                    double balance = sc.nextDouble();
                    //sc.nextLine();  // Consume the newline character
                    System.out.println("Enter Visitor Email: ");
                    String email = sc.next();
                    System.out.println("Enter Visitor Password: ");
                    String password = sc.next();
                    List<Integer> tickets1=new ArrayList<>();
                    Visitor visitor=new Visitor(name,age,phoneNumber,balance,email,password,tickets1,"none");
                    visitors1.add(visitor);
                    System.out.println("\nRegistration is successful.\n");
                    System.out.println("1.Register\n2.Login\n");
                    System.out.print("Enter your choice: ");
                    newUser=sc.nextInt();
                }

                else if(newUser==2){
                    System.out.println("Enter visitor email: ");
                    String email = sc.next();
                    System.out.println("Enter visitor password: ");
                    String password = sc.next();

                    for(Visitor v:visitors1){
                        if(v.getEmail().equalsIgnoreCase(email) && v.getPassword().equalsIgnoreCase(password)){
                            found=true;
                            System.out.println("\nLogin successful.\n");
                            List <Integer> ticketsList=new ArrayList<>();
                            v.setTickets(ticketsList);
                            int visitorChoice=0;
                            while (visitorChoice!=9){
                                System.out.println("Visitor Menu:\n" + //
                                        "1. Explore the Zoo\n" + //
                                        "2. Buy Membership\n" + //
                                        "3. Buy Tickets\n" + //
                                        "4. View Discounts\n" + //
                                        "5. View Special Deals\n" + //
                                        "6. Visit Animals\n" + //
                                        "7. Visit Attractions\n" + //
                                        "8. Leave Feedback\n" + //
                                        "9. Log Out\n" + //
                                        "");
                                System.out.println("Enter your choice: ");
                                visitorChoice=sc.nextInt();
                                switch(visitorChoice){
                                    case 9:
                                        break;
                                    case 1:
                                        int exploreMenu=0;
                                        while(exploreMenu!=3){
                                            System.out.println("Explore the Zoo:\r\n" + //
                                                    "1. View Attractions\r\n" + //
                                                    "2. View Animals\r\n" + //
                                                    "3. Exit\r\n" + //
                                                    "");
                                            System.out.println("Enter your choice: ");
                                            exploreMenu=sc.nextInt();
                                            switch(exploreMenu){
                                                case 3:
                                                    break;
                                                case 1:
                                                    System.out.println("\nAttractions in zoo: ");
                                                    for(Attraction attraction:attraction1){
                                                        System.out.println(attraction.getAttractionID()+". "+attraction.getName());
                                                    }
                                                    System.out.println("\nEnter your choice\n");
                                                    int despid=sc.nextInt();
                                                    for(Attraction attraction:attraction1){
                                                        if(despid==attraction.getAttractionID()){
                                                            System.out.println(attraction.getDescription()+"\n");
                                                        }
                                                    }
                                                    break;
                                                case 2:
                                                    System.out.println("\nAnimals in zoo: ");
                                                    int no=1;
                                                    for(Animal animal:animals1){
                                                        System.out.println(no+". "+animal.name());
                                                        no++;
                                                    }
                                                    break;
                                                default:
                                                    System.out.println("Invalid input");
                                                    break;

                                            }
                                        }
                                        break;
                                    case 2:
                                        System.out.println("Buy Membership:\r\n" + //
                                                "1. Basic Membership (₹20)\r\n" + //
                                                "2. Premium Membership (₹50)\r\n" + //
                                                "");
                                        double perc=0;
                                        System.out.println("Enter your choice: ");
                                        int membershipType = sc.nextInt();
                                        System.out.println("Apply Discount code: ");
                                        String discountCode = sc.next().toLowerCase();
                                        for (Discounts discount: discount1){
                                            if (discount.getCode().equalsIgnoreCase(discountCode)){
                                                perc=discount.getPercent();
                                            }
                                            if (discountCode.equals("none")){
                                                perc=0;
                                            }
                                        }
                                        if(membershipType == 1) {
                                            if (perc==0){
                                                double newBal=v.getBalance()-20;
                                                v.setBalance(newBal);
                                                v.setMembership("Basic");
                                                totRev+=20;
                                                System.out.println("\nBasic membership purchased. Your balance is "+newBal);
                                            }
                                            else{
                                                perc=perc/100;
                                                double newBal=(v.getBalance())-(20*(1-perc));
                                                totRev+=20*(1-perc);
                                                v.setBalance(newBal);
                                                v.setMembership("Basic");
                                                System.out.println("\nBasic membership purchased. Your balance is "+newBal);
                                            }

                                        }
                                        else if (membershipType==2){
                                            if (perc==0){
                                                double newBal=v.getBalance()-50;
                                                v.setBalance(newBal);
                                                v.setMembership("Premium");
                                                totRev+=50;
                                                System.out.println("\nPremium membership purchased. Your balance is "+newBal);
                                            }
                                            else{
                                                perc=perc/100;
                                                double newBal=(v.getBalance())-(50*(1-perc));
                                                v.setBalance(newBal);
                                                v.setMembership("Premium");
                                                totRev+=50*(1-perc);
                                                System.out.println("\nPremium membership purchased. Your balance is "+newBal);
                                            }

                                        }
                                        break;
                                    case 3:
                                        System.out.println("Buy Tickets:\nSelect an attraction\n");
                                        for(Attraction option:attraction1){
                                            System.out.println(option.getAttractionID()+". "+(option.getName())+"-"+option.getTicketPrice());

                                        }
                                        if(v.getMembership().equalsIgnoreCase("premium")){
                                            System.out.println("\nYou don't need to buy a ticket.\n");
                                        }
                                        else{
                                            System.out.println("\nEnter no of tickets: ");
                                            int buyTickets=sc.nextInt();
                                            double perc1=0;
                                            for(SpecialDeals deal:specialDeals1){
                                                if(deal.getNoTickets()==buyTickets){
                                                    perc1=deal.getDealPercentage();
                                                }
                                            }
                                            perc1=perc1/100;
                                            while(buyTickets!=0){
                                                System.out.println("Enter Attraction ID: ");
                                                int id = sc.nextInt();
                                                for(Attraction attraction:attraction1){
                                                    if(id == attraction.getAttractionID()){
                                                        attraction.setNoofTickets(attraction.getNoofTickets()+1);
                                                        double reqPrice=attraction.getTicketPrice()*(1-perc1);
                                                        ticketsList.add(id);
                                                        v.setBalance(v.getBalance()-reqPrice);
                                                        totRev+=reqPrice;

                                                    }
                                                }
                                                buyTickets--;
                                                //double newBal= v.getBalance()-

                                            }
                                        }
                                        break;
                                    case 4:
                                        System.out.println("Available Discounts: ");
                                        for (Discounts discount : discount1) {
                                            System.out.println(discount.getCategory()+" "+discount.getPercent()+"-"+discount.getCode());
                                        }
                                        break;
                                    case 5:
                                        //List<SpecialDeals> specialDeals = zooData.getSpecialDeals();
                                        //specialDeals=getSpecialDeals();
                                        for (SpecialDeals deal : specialDeals1) {
                                            System.out.println("Buy " + deal.getNoTickets() + " tickets and get " + deal.getDealPercentage() + "% off.");
                                        }
                                        break;
                                    case 6:
                                        System.out.println("Animals to visit: ");
                                        for(Animal animal:animals1){
                                            System.out.print(animal.name());
                                        }
                                        System.out.println("\nEnter Animal name: ");
                                        String animalName=sc.next();
                                        for(Animal animal:animals1){
                                            if(animal.name().equalsIgnoreCase(animalName)){
                                                System.out.println("\n1. Feed the animal\n2. Read about the animal\n");
                                                int animalchoice=sc.nextInt();
                                                switch(animalchoice){
                                                    case 1:
                                                        System.out.println(animal.makesound());
                                                        //animal.makesound();
                                                        break;
                                                    case 2:
                                                        //System.out.println(animal.history());
                                                        String hist=animal.history();
                                                        System.out.println(hist);
                                                        break;
                                                    default:
                                                        System.out.println("Invalid choice\n");
                                                        break;
                                                }

                                            }}

                                        break;
                                    case 7:
                                        boolean check=false;
                                        System.out.println("\nSelect Attraction to visit: ");
                                        for(Attraction attraction:attraction1){
                                            System.out.println(attraction.getAttractionID()+". "+attraction.getName());
                                        }
                                        System.out.println("\nEnter choice: ");
                                        int ch2 = sc.nextInt();
                                        if(v.getMembership().equalsIgnoreCase("premium")){
                                            for(Attraction attraction:attraction1){
                                                if(attraction.getAttractionID()==ch2){
                                                    System.out.println("Thank you for visiting "+attraction.getName());
                                                }
                                            }
                                        }
                                        else{
                                            List <Integer> checkTicket=v.getTickets();
                                            for(Integer x:checkTicket){
                                                //int x=x;
                                                if(x.intValue()==ch2){
                                                    check=true;
                                                    v.getTickets().remove(x);
                                                    for(Attraction attraction:attraction1){
                                                        if(attraction.getAttractionID()==ch2){
                                                            System.out.println("Thank you for visiting "+attraction.getName());
                                                        }
                                                    }

                                                }

                                            }
                                            if(check==false){
                                                System.out.println("\nYou are a basic member and do not have a ticket to visit this attraction.\n");
                                            }

                                        }

                                        break;
                                    case 8:
                                        System.out.println("Please enter feedback: ");
                                        String newFeedback=sc.nextLine();
                                        feedback1.add(newFeedback);
                                        break;
                                    default:
                                        System.out.println("Invalid Choice\n");
                                        break;


                                }
                                // System.out.println("Invalid username or password");
                            }

                        }
                    }
                    if(found==false){System.out.println("\nInvalid login credentials.\n");}
                }





            }
            else if(enterAs==3){
                //List<SpecialDeals> specialDeals = zooData.getSpecialDeals();
                //specialDeals=getSpecialDeals();
                for (SpecialDeals deal : specialDeals1) {
                    System.out.println("Buy " + deal.getNoTickets() + " tickets and get " + deal.getDealPercentage() + "% off.");
                }
            }
        }
        sc.close();
    }
}



package org.example;
import java.util.*;

public class SpecialDeals {
    private int noTickets,dealPercentage;

    public int getNoTickets() {
        return noTickets;
    }

    public void setNoTickets(int noTickets) {
        this.noTickets = noTickets;
    }

    public int getDealPercentage() {
        return dealPercentage;
    }

    public void setDealPercentage(int dealPercentage) {
        this.dealPercentage = dealPercentage;
    }

    public SpecialDeals(int noTickets, int dealPercentage) {
        this.noTickets = noTickets;
        this.dealPercentage = dealPercentage;
    }
}

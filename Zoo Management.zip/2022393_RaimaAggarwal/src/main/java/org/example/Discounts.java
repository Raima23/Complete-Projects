package org.example;
import java.util.*;
public class Discounts {
    private String category,code;
    private double percent;
    public Discounts(String category, double percent,String code) {
        this.category = category;
        this.code = code;
        this.percent = percent;
    }
    public String getCategory() {
        return category;
    }
    public String getCode() {
        return code;
    }
    public double getPercent() {
        return percent;
    }
    public void setCategory(String category) {
        this.category = category;
    }
    public void setCode(String code) {
        this.code = code;
    }
    public void setPercent(double percent) {
        this.percent = percent;
    }
}

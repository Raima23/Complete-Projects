package org.example;
import java.util.*;

public class Attraction {
    private String name,description;
    private int ticketPrice,attractionID,noofTickets,status;

    public Attraction(String name, String description, int ticketPrice, int attractionID, int noofTickets, int status) {
        this.name = name;
        this.description = description;
        this.ticketPrice = ticketPrice;
        this.attractionID = attractionID;
        this.noofTickets = noofTickets;
        this.status = status;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public int getTicketPrice() {
        return ticketPrice;
    }
    public void setTicketPrice(int ticketPrice) {
        this.ticketPrice = ticketPrice;
    }
    public int getAttractionID() {
        return attractionID;
    }
    public void setAttractionID(int attractionID) {
        this.attractionID = attractionID;
    }
    public int getNoofTickets() {
        return noofTickets;
    }
    public void setNoofTickets(int noofTickets) {
        this.noofTickets = noofTickets;
    }
    public int getStatus() {
        return status;
    }
    public void setStatus(int status) {
        this.status = status;
    }
}
